"""File to define Fish class."""

class Fish:
    
    def __init__(self):
        return None
    
    def one_day(self):
        return None