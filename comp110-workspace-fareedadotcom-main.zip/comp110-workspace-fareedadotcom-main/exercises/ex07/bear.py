"""File to define Bear class."""

class Bear:
    
    def __init__(self):
        return None
    
    def one_day(self):
        return None